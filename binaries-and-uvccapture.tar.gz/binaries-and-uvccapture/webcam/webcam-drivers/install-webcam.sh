insmod v4l2-common.ko
insmod v4l1-compat.ko
insmod compat_ioctl32.ko
insmod videodev.ko
insmod uvcvideo.ko
